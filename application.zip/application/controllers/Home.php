<?php
defined('BASEPATH') or exit('No direct script access allowed');

require_once( 'application/third_party/Smarty/Smarty.class.php' );

class Home extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('CI_Smarty');
        $smarty = new Smarty();
        session_start();
    }

    public function index()
    {
        $this->smarty->display('./body/accueil.tpl');
    }

    public function a_propos()
    {
        $this->smarty->display('./body/a_propos.tpl');
    }

    public function condition()
    {
        $this->smarty->display('./body/conditions.tpl');
    }

    public function connexion(){
      $this->smarty->display('./body/connexion.tpl');
    }

  /*  public function profil(){
      $this->load->model('Etudiant_model');
      $data['utilisateur'] = $this->Etudiant_model->getNomPrenom($_REQUEST['id']);
      $this->smarty->display('./body/profil.tpl');
    }*/

    public function inscription(){
      $this->smarty->display('./body/inscription.tpl');
    }

    public function recherche(){
      $this->smarty->display('./body/recherche.tpl');
    }

}
