<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Connexion extends CI_Controller
{
    public function __construct()
    {
        parent::__construct('connexion');
    }

    public function index()
    {
        $data = &$this->data;
        //$this->load->helper('form');

        if (isset($_POST['form_connexion'])) {
            $this->load->library('form_validation');
            $this->load->helper('url');

            $rules = array(
                array(
                        'field' => 'user_email',
                        'label' => 'Email',
                        'rules' => 'required'
                ),
                array(
                        'field' => 'user_mdp',
                        'label' => 'Password',
                        'rules' => 'required'
                )
        );

            $this->form_validation->set_rules($rules);

            if ($this->form_validation->run()) {
                if ($this->input->post('user_email') == "laurentdoiteau@free.fr") {
                  $_SESSION['prenom'] = $this->input->post('user_email');
                  // Prendre son id ?
                  header("Location: Profil");
                } else {
                    //$data['errors'] = array('Identifiant ou mot de passe incorrect.');
                    echo "Identifiant ou mot de passe incorrect.";
                }
            } else {
                //$data['errors'] = $this->form_validation->error_array();
                echo "PAS REMPLIE";
            }
        }
        $this->smarty->assign('body/connexion.tpl', $data);
        $this->smarty->display('./body/connexion.tpl');
    }
}
