<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Profil extends CI_Controller
{
    public function __construct()
    {
        parent::__construct('profil');
    }

    public function index()
    {
      if(!isset($_SESSION['prenom'])){
        header('Location: Connexion');
        echo "Vous n'êtes pas connecté.";
      }else{
        $data['session'] = 1; // Caractérise la connexion
      }
        $this->load->model('Etudiant_model');
        $data['utilisateur'] = $this->Etudiant_model->getNomPrenom($_SESSION['prenom']);
        $this->smarty->assign('data',$data);
        print_r($data);
        $this->smarty->display('./body/profil.tpl');
    }
}
