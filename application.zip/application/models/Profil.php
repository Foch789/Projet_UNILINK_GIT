<?php
defined('BASEPATH') or exit('No direct script access allowed');

require_once('BDD_models.php');

class Profil extends BDD_Models{

  public function getNomPrenom(){
    
  }
}

?>
